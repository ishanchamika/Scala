object b {

  def main(args: Array[String]): Unit =
  {
    val plaintext = "FuNctiOnaL ProgRAmMing"
    val shift = 1

    val encrypted = cipher(plaintext, caesarEncrypt, shift)
    println(s"Encrypted Text: " + encrypted)

    val decrypted = cipher(encrypted, caesarDecrypt, shift)
    println(s"Decrypted Text: " + decrypted)
  }


  def cipher(text: String, operation: (String, Int) => String, shift: Int): String =
  {
    operation(text, shift)
  }

  def caesarEncrypt(plaintext: String, shift: Int): String =
  {
    val encrypt = plaintext.map
    {
      char =>
        if (char.isLetter)
        {
          val base = if (char.isUpper) 'A' else 'a'
          val shifted = ((char - base + shift) % 26 + base).toChar
          shifted
        }
        else
        {
          char
        }
    }
    encrypt
  }

  def caesarDecrypt(ciphertext: String, shift: Int): String =
  {
    val decrypt = ciphertext.map
    {
      char =>
        if (char.isLetter)
        {
          val base = if (char.isUpper) 'A' else 'a'
          val shifted = ((char - base - shift + 26) % 26 + base).toChar
          shifted
        }
        else
        {
          char
        }
    }
    decrypt
  }
}
