object Main {
  def main(args: Array[String]): Unit =
  {
    val plaintext = "FuNctiOnaL ProgRAmMing"
    val shift = 1

    val encrypted = caesarEncrypt(plaintext, shift)
    println(s"Encrypted Text: "+encrypted)

    val decrypted = caesarDecrypt(encrypted, shift)
    println(s"Decrypted Text: "+decrypted)
  }


    def caesarEncrypt(plaintext: String, shift: Int): String =
    {
      val encrypt = plaintext.map
      {
        char =>
        if (char.isLetter)
        {
          val base = if (char.isUpper) 'A' else 'a'
          val shifted = ((char - base + shift) % 26 + base).toChar
          shifted
        }
        else
        {
          char
        }
      }
      encrypt
    }

    def caesarDecrypt(ciphertext: String, shift: Int): String =
    {
      val decrypt = ciphertext.map
      {
        char =>
        if (char.isLetter)
        {
          val base = if (char.isUpper) 'A' else 'a'
          val shiftedChar = ((char - base - shift + 26) % 26 + base).toChar
          shiftedChar
        }
        else
        {
          char
        }
      }
      decrypt
    }
}